document.addEventListener('DOMContentLoaded', function() {
    
    function validateForm() {
      
      var firstName = document.getElementById('firstName').value.trim();
      var lastName = document.getElementById('lastName').value.trim();
      var phoneNumber = document.getElementById('phoneNumber').value.trim();
      var email = document.getElementById('email').value.trim();
      var street = document.getElementById('street').value.trim();
      var city = document.getElementById('city').value.trim();
      var state = document.getElementById('state').value.trim();
      var zipCode = document.getElementById('zipCode').value.trim();
      var coverLetter = document.getElementById('coverLetter').value.trim();
      var education = document.getElementById('education').value.trim();
      var school = document.getElementById('school').value.trim();
      var major = document.getElementById('major').value.trim();
      var graduationYear = document.getElementById('graduationYear').value.trim();
      var jobTitles = document.getElementById('jobTitles').value.trim();
      var companies = document.getElementById('companies').value.trim();
      var employmentDates = document.getElementById('employmentDates').value.trim();
      var responsibilities = document.getElementById('responsibilities').value.trim();
      var skills = document.getElementById('skills').value.trim();
      var startDate = document.getElementById('startDate').value.trim();
      var workSchedule = document.getElementById('workSchedule').value.trim();
      var referenceName = document.getElementById('referenceName').value.trim();
      var referenceContact = document.getElementById('referenceContact').value.trim();
      var relationship = document.getElementById('relationship').value.trim();
      var whyWorkHere = document.getElementById('whyWorkHere').value.trim();
      var termsCheckbox = document.getElementById('termsCheckbox').checked;
      var privacyPolicyCheckbox = document.getElementById('privacyPolicyCheckbox').checked;

      if (firstName === '' || lastName === '' || phoneNumber === '' || email === '' || street === '' ||
          city === '' || state === '' || zipCode === '' || coverLetter === '' || education === '' ||
          school === '' || major === '' || graduationYear === '' || jobTitles === '' || companies === '' ||
          employmentDates === '' || responsibilities === '' || skills === '' || startDate === '' ||
          workSchedule === '' || referenceName === '' || referenceContact === '' || relationship === '' ||
          whyWorkHere === '' || !termsCheckbox || !privacyPolicyCheckbox) {
        return false;
      }
  

      var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return false;
      }
  
   
      var phoneRegex = /^\d{3}-?\d{3}-?\d{4}$/;
      if (!phoneRegex.test(phoneNumber)) {
        return false;
      }
  
      
      return true;
    }
  
   
    function transformData() {
     
      var formData = {
        'First Name': document.getElementById('firstName').value.trim(),
        'Last Name': document.getElementById('lastName').value.trim(),
        'Phone Number': document.getElementById('phoneNumber').value.trim(),
        'Email Address': document.getElementById('email').value.trim(),
        'Address': document.getElementById('street').value.trim() + ', ' +
                   document.getElementById('city').value.trim() + ', ' +
                   document.getElementById('state').value.trim() + ', ' +
                   document.getElementById('zipCode').value.trim(),
        'Cover Letter': document.getElementById('coverLetter').value.trim(),
        'Highest Education': document.getElementById('education').value.trim(),
        'School/University': document.getElementById('school').value.trim(),
        'Major/Area of Study': document.getElementById('major').value.trim(),
        'Graduation Year': document.getElementById('graduationYear').value.trim(),
        'Previous Job Titles': document.getElementById('jobTitles').value.trim(),
        'Company Names': document.getElementById('companies').value.trim(),
        'Employment Dates': document.getElementById('employmentDates').value.trim(),
        'Job Responsibilities': document.getElementById('responsibilities').value.trim(),
        'Skills': document.getElementById('skills').value.trim(),
        'Start Date': document.getElementById('startDate').value.trim(),
        'Preferred Work Schedule': document.getElementById('workSchedule').value.trim(),
        'Willingness to Relocate': document.getElementById('relocate').value.trim(),
        'Reference Name': document.getElementById('referenceName').value.trim(),
        'Reference Contact Information': document.getElementById('referenceContact').value.trim(),
        'Relationship to Applicant': document.getElementById('relationship').value.trim(),
        'Why Work Here': document.getElementById('whyWorkHere').value.trim()
      };
  
    
      var tableHTML = '<table class="table"><tbody>';
      for (var key in formData) {
        tableHTML += '<tr><td>' + key + '</td><td>' + formData[key] + '</td></tr>';
      }
      tableHTML += '</tbody></table>';
  
   
      document.getElementById('dataTableContainer').innerHTML = tableHTML;
    }
  
   
    document.getElementById('jobApplicationForm').addEventListener('submit', function(event) {
      event.preventDefault(); 
      if (validateForm()) {
   
        this.submit();
        alert('Data is successfully saved!');
        
        clearFormFields();
      } else {
  
        alert('Please fill out all required fields correctly.');
      }
    });

    document.getElementById('transformDataBtn').addEventListener('click', function() {
      transformData();
    });
  });
  